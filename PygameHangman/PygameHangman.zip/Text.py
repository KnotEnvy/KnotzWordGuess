import pygame

class Text:
    def __init__(self, text, font, surface):
        self.text = text
        self.font = font
        self.surface = surface
        self.color = (10, 10, 10)
        self.position = (0, 0)

    def set_text(self, text):
        self.text = text

    def draw(self, position):
        self.position = position
        text_surface = self.font.render(self.text, True, self.color)
        self.surface.blit(text_surface, self.position)
