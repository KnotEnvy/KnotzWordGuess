import pygame
from Hangman import Hangman
from Text import Text  # New class for animated text

# Define some constants
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
DARK_BLUE = (0, 0, 139)
ORANGE = (255, 165, 0)

class Screen:
    def __init__(self):
        pygame.font.init()
        self.DISPLAYSURF = pygame.display.set_mode((600, 800), pygame.RESIZABLE)
        pygame.display.set_caption('Knotz WordGuess')
        self.font = pygame.font.Font(None, 36)
        self.hangman = Hangman(self.DISPLAYSURF)
        self.message = Text("", self.font, self.DISPLAYSURF)  # Use the new Text class for the message

    def display_start_screen(self):
        # Draw a gradient background
        for i in range(self.DISPLAYSURF.get_height()):
            color = max(0, 255 - i // 3)
            pygame.draw.line(self.DISPLAYSURF, (color, color, 255), (0, i), (self.DISPLAYSURF.get_width(), i))

        title_text = self.font.render('Knotz WordGuess!', True, DARK_BLUE)
        subtitle_text = self.font.render('Guess the word one letter at a time', True, BLACK)
        instruction_text = self.font.render('Press Enter to start', True, ORANGE)

        title_text_rect = title_text.get_rect(center=(self.DISPLAYSURF.get_width() // 2, self.DISPLAYSURF.get_height() // 4))
        subtitle_text_rect = subtitle_text.get_rect(center=(self.DISPLAYSURF.get_width() // 2, self.DISPLAYSURF.get_height() // 2))
        instruction_text_rect = instruction_text.get_rect(center=(self.DISPLAYSURF.get_width() // 2, self.DISPLAYSURF.get_height() * 3 // 4))

        self.DISPLAYSURF.blit(title_text, title_text_rect)
        self.DISPLAYSURF.blit(subtitle_text, subtitle_text_rect)
        self.DISPLAYSURF.blit(instruction_text, instruction_text_rect)

        pygame.display.flip()

        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    return False
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_RETURN:
                        return True

    def display_difficulty_screen(self):
        # Draw a gradient background
        for i in range(self.DISPLAYSURF.get_height()):
            color = max(0, 255 - i // 3)
            pygame.draw.line(self.DISPLAYSURF, (color, color, 255), (0, i), (self.DISPLAYSURF.get_width(), i))

        title_text = self.font.render('Select Difficulty Level', True, DARK_BLUE)
        easy_text = self.font.render('1. Easy', True, BLACK)
        medium_text = self.font.render('2. Medium', True, BLACK)
        hard_text = self.font.render('3. Hard', True, BLACK)
        expert_text = self.font.render('4. Expert', True, BLACK)

        title_text_rect = title_text.get_rect(center=(self.DISPLAYSURF.get_width() // 2, self.DISPLAYSURF.get_height() // 4))
        easy_text_rect = easy_text.get_rect(center=(self.DISPLAYSURF.get_width() // 2, self.DISPLAYSURF.get_height() // 2 - 50))
        medium_text_rect = medium_text.get_rect(center=(self.DISPLAYSURF.get_width() // 2, self.DISPLAYSURF.get_height() // 2))
        hard_text_rect = hard_text.get_rect(center=(self.DISPLAYSURF.get_width() // 2, self.DISPLAYSURF.get_height() // 2 + 50))
        expert_text_rect = expert_text.get_rect(center=(self.DISPLAYSURF.get_width() // 2, self.DISPLAYSURF.get_height() // 2 + 100))

        self.DISPLAYSURF.blit(title_text, title_text_rect)
        self.DISPLAYSURF.blit(easy_text, easy_text_rect)
        self.DISPLAYSURF.blit(medium_text, medium_text_rect)
        self.DISPLAYSURF.blit(hard_text, hard_text_rect)
        self.DISPLAYSURF.blit(expert_text, expert_text_rect)

        pygame.display.flip()

        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    return False
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_1:
                        return 'easy'
                    if event.key == pygame.K_2:
                        return 'medium'
                    if event.key == pygame.K_3:
                        return 'hard'
                    if event.key == pygame.K_4:
                        return 'expert'


    def display_message(self, message):
        self.message.set_text(message)  # Use the new Text class to set the message

    def display_game_screen(self, player, word_bank):
        self.DISPLAYSURF.fill((255, 255, 255))
        # Draw hangman
        self.hangman.draw(player.get_wrong_guesses())

        # Adjust font size based on the length of the word
        font_size = min(36, self.DISPLAYSURF.get_width() // len(word_bank.get_display_word()))
        font = pygame.font.Font(None, font_size)

        word_text = Text(word_bank.get_display_word(), font, self.DISPLAYSURF)  # Use the new Text class for the word to guess
        guess_text = self.font.render("Wrong guesses: " + str(player.get_wrong_guesses()), True, (10, 10, 10))
        word_text.draw((50, 100))  # Use the new Text class to draw the word to guess
        self.DISPLAYSURF.blit(guess_text, (50, 150))
        pygame.display.flip()

    def display_end_screen(self, won, word, player):
        self.DISPLAYSURF.fill((255, 255, 255))
        if won:
            end_text = self.font.render("Congratulations, you won!", True, DARK_BLUE)
        else:
            end_text = self.font.render("You did not make it. The word was " + word, True, BLACK)
        end_text_rect = end_text.get_rect(center=(self.DISPLAYSURF.get_width() // 2, self.DISPLAYSURF.get_height() // 2))
        self.DISPLAYSURF.blit(end_text, end_text_rect)
        pygame.display.flip()

    def ask_restart(self):
        self.DISPLAYSURF.fill((255, 255, 255))
        restart_text = self.font.render("Would you like to play again? (yes/no)", True, ORANGE)
        restart_text_rect = restart_text.get_rect(center=(self.DISPLAYSURF.get_width() // 2, self.DISPLAYSURF.get_height() // 2))
        self.DISPLAYSURF.blit(restart_text, restart_text_rect)
        pygame.display.flip()

        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    exit()
                if event.type == pygame.KEYDOWN:
                    if event.unicode.lower() in ['y', 'yes']:
                        return True
                    if event.unicode.lower() in ['n', 'no']:
                        return False
